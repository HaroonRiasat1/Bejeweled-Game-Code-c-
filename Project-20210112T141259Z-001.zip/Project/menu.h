#ifndef MENU_H
#define MENU_H
#include"filereading.h"
class menu
{
protected:
int option;
bool trialmood=false;
bool a=false,b=false,c=false,d=false;
int f,g,h,e;
File A;
public:
void drawmenu();
menu();
int getoption();
void setoption(int x);
void Drawlevel();
void optionmenu(int,int);
void Drawlevelmod();
void Drawsettings();
bool trailmod();
void Drawfile();
void Animation();

};
#endif