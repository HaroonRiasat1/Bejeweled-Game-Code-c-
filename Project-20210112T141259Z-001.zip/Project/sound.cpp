#include"sound.h"
soundmp3::soundmp3()
{

}
void soundmp3::sound1()
{
    SoundEngine->play2D("CandyCrush.mp3");
}
void soundmp3::sound2()
{
    SoundEngine->play2D("CandyCrush1.mp3");
}
void soundmp3::sound3()
{
   if(A)
  {
      ISoundEngine *SoundEngine2 = createIrrKlangDevice();
  }
    SoundEngine2->play2D("hello.mp3",true);
}
void soundmp3::sound4()
{
  if(A)
  {
      ISoundEngine *SoundEngine2 = createIrrKlangDevice();
  }
    SoundEngine2->play2D("breakout.mp3",true);
}
void soundmp3::deletesound()
{
    SoundEngine2->drop();
    A=true;
}