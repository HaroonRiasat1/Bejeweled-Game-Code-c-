#include"menu.h"
#include"util.h"

menu::menu()
{
    option=0;
}
int menu::getoption()
{
    return option;
}
void menu::setoption(int c)
{
    option=c;
}

void menu::drawmenu()
{
        	
            for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, i-200+g ,i,colors[MAROON]);     
            }
            DrawString( 350, 740,"Bejeweled Game", colors[BLACK]); 

            DrawString( 350, 340+g,"PLAY GAME", colors[WHITE]); 
            DrawString( 350, 240+g,"LEVEL", colors[WHITE]);
            DrawString( 350, 140+g,"LEVEL MODES", colors[WHITE]); 
            DrawString( 350, 40+g,"HIGHSCORES", colors[WHITE]); 
            DrawString( 350, -60+g,"SETTINGS", colors[WHITE]); 
             DrawString( 575, -100+g,"USER STATE", colors[WHITE]); 
            DrawRoundRect(400,870-g,50,60,colors[NAVY],50);
			DrawSquare( 400+10, 870+15-g,30,colors[BLACK]);
            Animation();
            DrawCircle(40+20, 540+20-g, 50,colors[MAROON]);
			DrawCircle(40+20, 540+20-g, 25,colors[GOLDEN_ROD]);
            DrawSquare( 720, 140+g ,70,colors[VIOLET]);
			DrawSquare( 720+18, 140+18+g ,35,colors[FLORAL_WHITE]);
            	DrawRectangle(400, 210-g, 60, 80, colors[NAVY]);
				DrawRectangle(400+16, 210+22-g,30, 40, colors[HOT_PINK]);
        glutPostRedisplay(); 
          //system("pause");
          }
          void menu::Drawlevel()
          {
              for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, i-200+e ,i,colors[BLUE]);     
            }
             Animation();
            DrawSquare( 140, 540-e ,70,colors[VIOLET]);
            DrawString( 170, 560-e,"1", colors[WHITE]); 
            DrawSquare( 340, 540-e ,70,colors[VIOLET]);
            DrawString( 370, 560-e,"2", colors[WHITE]); 
            DrawSquare( 540, 540-e,70,colors[VIOLET]);
            DrawString( 570, 560-e,"3", colors[WHITE]); 
            DrawSquare( 740, 540-e ,70,colors[VIOLET]);
            DrawString( 770, 560-e,"4", colors[WHITE]); 

glutPostRedisplay(); 
        }
        void menu::Drawlevelmod()
        {
           for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, i ,i,colors[MAROON]);     
            }   
            DrawSquare( 140, 340 ,200,colors[VIOLET]);
            DrawString( 160, 400,"Normal Mode", colors[WHITE]); 
            DrawSquare( 540, 340 ,200,colors[VIOLET]);
            DrawString( 560, 400,"Trial Mode", colors[WHITE]);



        }
    void menu::Drawsettings()
    {
        for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, 0+800-(f*4),i,colors[MAROON]);     
            } 
         DrawString( 0,800-200+f,"1)To Play Music Press B key ", colors[WHITE]);
         DrawString( 0,760-200+f,"2)To exit game press esc key ", colors[WHITE]);
         DrawString(0,720-200+f,"_____________________________How to Play______________________________",colors[WHITE]);
         DrawString( 0,680-200+f,"Swap to gems by pressing one then other if three gems matches diagonally", colors[WHITE]);
         DrawString( 0,640-200+f,"or horizontally you'll get point you have limited moves", colors[WHITE]);
         DrawString( 0,600-200+f,"To pass each level you need to score 500 score in each level", colors[WHITE]);
        
        Animation();

glutPostRedisplay(); 

         
         
//\n 2)To exit game press esc key \n___________How to Play__________\nSwap to gems by pressing one then other if three gems matches diagonally \n or horizontally you'll get point you have limited moves\nTo pass each level you need to score 500 score in each level



    }

          void menu::optionmenu(int x,int y){
              			if((x>=350&&x<=490)&&(y>=281&&y<=303)&&(this->getoption()==0))
	{
			this->setoption(1);
	}
			if((x>=350&&x<=425)&&(y>=380&&y<=400)&&(this->getoption()==0))
	{
			this->setoption(2);
	}
    		if((x>=350&&x<=495)&&(y>=480&&y<=501)&&(this->getoption()==0))
	{
			this->setoption(3);
	}
    		if((x>=348&&x<=471)&&(y>=678&&y<=700)&&(this->getoption()==0))
	{
			this->setoption(4);
	}
    	if((x>=140&&x<=341)&&(y>=301&&y<=499)&&(this->getoption()==3))
	{
			this->setoption(1);
            trialmood=false;
	}
    	if((x>=539&&x<=738)&&(y>=301&&y<=499)&&(this->getoption()==3))
	{
			
            trialmood=true;
             DrawString( 800, 400,"Trial Mode", colors[WHITE]);
             this->setoption(1);
	}
  	if((x>=350&&x<=490)&&(y>=581&&y<=605)&&(this->getoption()==0))
	{
			this->setoption(5);
            trialmood=false;
	}
    	if((x>=569&&x<=721)&&(y>=713&&y<=745)&&(this->getoption()==0))
	{
			this->setoption(6);
          
	}



          };
bool menu::trailmod()
{
    return trialmood;
}
void menu::Drawfile()
{
     for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, 0 ,i,colors[GREEN_YELLOW]);     
            } 

    A.fileread();




}

void menu::Animation()
{
    if(b==false){
        g++;
	}
	if(g==200){
		b=true;
	}
	
	if(c==false&&this->getoption()==2){
        e++;
	}
	if(e==200){
		c=true;
	}
    	if(a==false&&this->getoption()==4){
        f++;
	}
	if(f==200){
		a=true;
	}
}