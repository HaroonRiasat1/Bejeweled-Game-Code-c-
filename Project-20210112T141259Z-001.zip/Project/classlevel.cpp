#include"classlevel.h"
classlevel::classlevel(/* args */){
    lives=3;
    noofmoves=25;
    level=1;
    noofmovesplayed=0;
};
    int classlevel::getlevel(){
            return level;
    };
    void classlevel::setlevel(){
        ++level;

    };
    int classlevel::getlives(){
        return lives;

    };
    int classlevel::getnoofmoves(){
        return noofmoves;
    };
    void classlevel::setnoofmoves(int moves){
        noofmoves=moves;

    };
    void classlevel::setnoofmovesplayed(int played){
        noofmovesplayed=played;
    };
      int classlevel::getnoofmovesplayed(){
        return noofmovesplayed;
    };
    void classlevel::setlives(int x)
    {
        lives=x;
    }