 #include"filereading.h"
 #include"game.cpp"
File::File(){};
void File::highscorewrite(string user,int highscore,int num,int lives,int lev){

    ofstream Fileout;
  Fileout.open("Highscore.txt", ios::out|ios::app);
 

  Fileout << "\n Name: "<< user;
  Fileout << "\n Highscore: " <<highscore;
  Fileout<<"\n No of moves played:"<<num;
  Fileout<<"\n no of lives remaining:"<<lives;
  Fileout<<"\n Maximum level"<<lev;
  Fileout<<"\n_________________________";
  
  Fileout.close();

};
void File::fileread(){
  ifstream Filein;
  string linein;
  
  Filein.open("Highscore.txt");
  int i=800;
  while( ! Filein.eof( ))
  {
      getline(Filein, linein);
  	  DrawString( 0, i,linein, colors[MISTY_ROSE]);
    i=i-30;
  }

  
  Filein.close();





};