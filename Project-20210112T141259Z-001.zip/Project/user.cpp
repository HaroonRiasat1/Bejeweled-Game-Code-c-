#include"user.h"
    User::User(){
    username=" ";
    highscore=0;
    score=0;    
  };
    User::User(string name){
        username=name;
    };
    User::User(string name, int highscore1){
    username=name;
    highscore=highscore1;
    score=highscore1;    

    };
   void User::sethighscore(int highscore1){
       highscore=highscore1;
   };
    int User::gethighscore(){
        if(highscore<score)
        highscore=score;
        return highscore;
    };
    void User::setscore(int score1){
       score=score1;
   };
    int User::getscore(){
        return score;
    };
    void User::setusername(string username1){
        username=username1;
    };
    string User::getsusername(){
        return username;
    };

istream &operator>>(istream& output,const User&A){
    

     
         cout<<"Please enter Your name:";
         output>>A.username;
        
     
 
 return output;
 };