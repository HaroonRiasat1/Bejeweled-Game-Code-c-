#ifndef DRAW_H
#define DRAW_H
#include<iostream>
#include"util.h"
#include"h.h"
#include<cstdlib>
#include<ctime>
#include"user.cpp"
#include"irrKlang.h"
#include"sound.cpp"
#include"classlevel.cpp"
#include"menu.cpp"
#include"filereading.cpp"
class Draw: public soundmp3,public classlevel,public menu
{
private:
int x;
int y;
int count;
char array1[8][8];
int arr[8][8];
int a,b,a2,b2,t;
Draw1 ***ar=new Draw1**[8];
User A;
int checker=0;
int checker2;
File data;
float timee;
string timeee;
//soundmp3 B;



public:
Draw();
Draw(int x1, int y1);
void Drawdisplay();
void Drawmovableobj();
char array3();
void checkrowandcol();
void move(int x12,int y12);
int getcount();
void setcount(int h);
int sound();
void username();
void gethint();
void time1();

};

#endif
