#include"classdraw.h"
#include"irrKlang.h"
using namespace irrklang;

Draw::Draw()
{
    x=0;
    y=0;
	count=0;
	checker2=0;

int l=1;
	
  string A2;
  cout<<endl;
  cout<<"Please enter your username:";
  cin>>A2;
  A.setusername(A2);
  
  srand(time(0));
  
	  
   for(int i=0;i<8;i++)
   {		
	 
	  for(int j=0;j<8;j++)
	  {
	
	  
       arr[i][j]=1+rand()%5;
	  
		l++;
	  }	
   }


for(int i = 0 ; i < 8 ; i++)
{       
    ar[i] = new Draw1*[8];   
}

for(int i = 0 ; i < 8 ; i++)
{       
    for(int j = 0 ; j < 8 ; j++)
    {
        ar[i][j] = new Draw1[8]; 

    }
}

	
}
Draw::Draw(int x1, int y1)
{
    x=x1;
    y=y1;
	

  
}
void Draw::Drawdisplay()
{

    DrawLine( 840 , 840 ,  840 , 0 , 500 , colors[RED] );
    DrawLine( 0 , 840 ,  840 , 840 , 500 , colors[RED] );
    DrawLine(100,840,100,0,500,colors[RED]);
     DrawLine(100,100,840,100,500,colors[RED]);
	if(A.getscore()>=480&&this->trailmod()==true)
	{
		DrawString( 25, 720,"Game ended", colors[MISTY_ROSE]);
		A.setscore(0);
		this->setnoofmoves(25);
		this->setlives(3);
		this->setoption(0);
	}

	if(this->trailmod()==false)
	{
		DrawString( 10, 740,"Level", colors[MISTY_ROSE]);
		DrawString( 25, 720,to_string(this->getlevel()), colors[MISTY_ROSE]);
	}
	else
	{
		DrawString( 10, 740,"Level", colors[MISTY_ROSE]);
		DrawString( 25, 720,"Trial", colors[MISTY_ROSE]);
	}
	
		DrawString( 10, 680,"Moves", colors[MISTY_ROSE]);
		DrawString( 25, 660,to_string(this->getnoofmoves()), colors[MISTY_ROSE]);
	if(A.getscore()%500==0&&A.getscore()!=0&&this->trailmod()==0)
	{
		this->setlevel();
		A.setscore(A.getscore()+10);
		this->setnoofmoves(25);
	}
	if(A.getscore()>=500&&A.getscore()<=1000&&this->getlevel()!=2&&this->trailmod()==0)
	{
	this->setlevel();
		A.setscore(A.getscore()+10);
		this->setnoofmoves(25);	
	}
	if(A.getscore()>=1001&&A.getscore()<=1500&&this->getlevel()!=3&&this->trailmod()==0)
	{
	this->setlevel();
		A.setscore(A.getscore()+10);
		this->setnoofmoves(25);	
	}
	if(A.getscore()>=1501&&A.getscore()<=2000&&this->getlevel()!=4&&this->trailmod()==0)
	{
	this->setlevel();
		A.setscore(A.getscore()+10);
		this->setnoofmoves(25);	
	}
	
	if(this->trailmod()==true&&checker2==0)
	{
		A.setscore(200);
		this->setnoofmoves(10);
		checker2++;
	}
	if(this->getlives()==0)
	{
		data.highscorewrite(A.getsusername(),A.gethighscore(),this->getnoofmovesplayed(),this->getlives(),this->getlevel());
		A.setscore(0);
		this->setnoofmoves(25);
		this->setlives(3);
		
		this->setoption(0);
	}
	if(this->getnoofmoves()==0&&this->getlives()!=0)
	{
		if(this->getlives()!=0)
		A.setscore(A.getscore()/2);
		this->setlives(this->getlives()-1);
		this->setnoofmoves(25);
	}

if(this->getlives()==3)
{
	DrawCircle(10,620,10,colors[RED]);
	DrawCircle(30,620,10,colors[RED]);
	DrawCircle(50,620,10,colors[RED]);
}

if(this->getlives()==2)
{
	DrawCircle(10,620,10,colors[RED]);
	DrawCircle(30,620,10,colors[RED]);
	//DrawCircle(50,620,10,colors[RED]);
}

if(this->getlives()==1)
{
	DrawCircle(10,620,10,colors[RED]);
//	DrawCircle(30,620,10,colors[RED]);
//	DrawCircle(50,620,10,colors[RED]);
}


 DrawString( 10, 800, A.getsusername(), colors[MISTY_ROSE]);
DrawString( 10, 780,"Score:", colors[MISTY_ROSE]);
 DrawString( 10, 760, to_string(A.getscore()), colors[MISTY_ROSE]);
	
};


void Draw::Drawmovableobj()
{
	
	int r=0;
	int c=0;
		for(int i=120;i<800;)
		{
			c=0;
			for(int j=120;j<800;)
			{
				ar[0][r][c].setx(i);

				ar[0][r][c].sety(j);
				j=j+90.25;
				c++;
			}
			i=i+90.25;
			r++;
		}
	
	A.sethighscore(A.getscore());
	
	
	
	
	int h=0;
	int k=0;
	int p=0;
	  	for(int i=120;i<800;)
		  { 
			  if(k==8)
			  k=0;
			  for(int j=120;j<800;)
			  {
			
		
		if(arr[h][k]==2)
		{
			DrawSquare( i, j ,50,colors[VIOLET]);
			DrawSquare( i+12, j+12 ,25,colors[FLORAL_WHITE]);
			array1[h][k]='S';
			p++;
		}
			else if(arr[h][k]==1)
			{
				DrawRoundRect(i,j,50,60,colors[MAGENTA],50);
					DrawSquare( i+10, j+15,30,colors[BLACK]);
				array1[h][k]='R';
				p++;
			}
		else if(arr[h][k]==5)
		{	
				 DrawCircle(i+20, j+20, 30,colors[MAROON]);
				  DrawCircle(i+20, j+20, 15,colors[GOLDEN_ROD]);
					array1[h][k]='C';
					p++;
		}		 
				 		else if(arr[h][k]==3)
						 {
				  DrawTriangle( i, j, i+22, j+45,i+45, j+22,colors[RED]);
				  DrawTriangle( i, j, i+12, j+35,i+35, j+12,colors[RED]);
						 	array1[h][k]='T';
							 p++;
						 }
						 else if(arr[h][k]==4)
			  			{
							  
						  	DrawRectangle(i, j, 45, 60, colors[NAVY]);
						  	DrawRectangle(i+12, j+15, 22.5, 30, colors[HOT_PINK]);

							  

							  

							array1[h][k]='F';
							p++;
						  }
						  	else if(arr[h][k]==0)
		{
			arr[h][k]=1+rand()%5;
		}	  
		else if(arr[h][k]==9)
		{
			DrawCircle(i+20, j+20, 30,colors[ORANGE]);
				  DrawCircle(i+20, j+20, 15,colors[BLUE]);
					array1[h][k]='H';
					p++;
		}
		


						 k++;
					j=j+90.25;
			  }
	
		  
			  
			  h++;
			  i=i+90.25;
			  
		  }

for(int i=0;i<8;i++)
{
 for(int j=0;j<8;j++)
{
cout<<array1[i][j]<<" ";
}
cout<<endl;
}



DrawLine( 100 , 50 ,  100+A.getscore()-timee*1.5 , 50 , 1000 , colors[MAROON] );

DrawLine( 100 , 740 , 840 , 740 , 1000 , colors[RED] );


glutPostRedisplay();
}
char Draw::array3()
{
	return **array1;
}
void Draw::checkrowandcol()
{
	int h=0,k=0;
	for(int i=120;i<800;)
	{
		k=0;
		for(int j=120;j<800;)
		{
			  
			if(array1[h][k]==array1[h][k+1]&&array1[h][k+1]==array1[h][k+2])//&&k!=7&&k!=8)
			{
		
				for (int i = k; i <7; i++)
				{
					arr[h][i]=arr[h][i+1];
					arr[h][i+1]=0;
						if(i==k)
					{
							A.setscore(A.getscore()+10);
						this->sound2();
					}
				}
				for (int i = k+1; i <7; i++)
				{
					arr[h][i]=arr[h][i+1];
					arr[h][i+1]=0;
				}
				for (int i = k+2; i <7; i++)
				{
					arr[h][i]=arr[h][i+1];
					arr[h][i+1]=0;
				}

			//	A.setscore(A.getscore()+10);

			}
			if(array1[h+1][k]==array1[h][k]&&array1[h+1][k]==array1[h+2][k])//&&h!=7&&h!=8)
			{
			

				for (int i = k; i <7; i++)
				{
					arr[h][i]=arr[h][i+1];
					arr[h][i+1]=0;
					if(i==k)
					{
							A.setscore(A.getscore()+10);
						this->sound1();
						
					}
				}
				for (int i = k; i <7; i++)
				{
					arr[h+1][i]=arr[h+1][i+1];
					arr[h+1][i+1]=0;
				}
					for (int i = k; i <7; i++)
				{
					arr[h+2][i]=arr[h+1][i+1];
					arr[h+2][i+1]=0;
				}
			if(k==8)
			{
				arr[h+1][k]=0;
				arr[h+2][k]=0;
				arr[h][k]=0;

			}
			

			}
			 k++;
					j=j+90.25;	
		}
		  h++;
			  i=i+90.25;
	}
		
		
}
void Draw::move(int x12,int y12)
{
	cout<<"helloharoon"<<x12<<" "<<y12<<endl;
int h=0,k=6;
	cout<<"The count is:"<<count<<endl;
	for (int i = 120; i < 800; )
	{
		k=6;
		for ( int j=120; j < 800; j++)
		{
			if ((x12>=i&&x12<=i+90)&&(y12>=j&&y12<=j+90)&&count==0)
			{
				cout<<"Equal to"<<h<<" "<<k;
				cout<<endl;
				a=h;
				b=k;
			}
			if ((x12>=i&&x12<=i+90)&&(y12>=j&&y12<=j+90)&&count==1)
			{
				cout<<"Equal to"<<h<<" "<<k;
				cout<<endl;
				a2=h;
				b2=k;
			}

			k--;
			j=j+90.25;
		}
		i=i+90.25;
		h++;
	}
int m=0,l=6;
for(int i=120;i<800;)
{
	l=6;
	for (int  j = 120; j <800;)
	{
		cout<<"["<<m<<"]["<<l<<"]";
			l--;
			j=j+90.25;
	}
	cout<<endl;
	i=i+90.25;
		m++;
	
}

if(count==1)
{

	if(checker==1)
	{
	this->setnoofmoves(this->getnoofmoves()-1);
	this->setnoofmovesplayed(this->getnoofmovesplayed()+1);
	checker=0;
	}
	else
	{
		checker++;
	}
	


}

	
if((count==1)&&((((array1[a][b]==array1[a2][b2+1])&&(array1[a][b]==array1[a2+1][b2]))||((array1[a][b]==array1[a2][b2+2])&&(array1[a][b+2]==array1[a2][b2+3]))||(((array1[a][b]==array1[a2][b2-1])
&&(array1[a][b]==array1[a2-1][b2]))||((array1[a][b]==array1[a][b+1])&&array1[a][b]==array1[a+1][b+1]))||((array1[a][b]==array1[a][b+1])&&array1[a][b]==array1[a-1][b-1])||((array1[a][b]==array1[a][b+1])
&&array1[a][b+1]==array1[a][b+3])||((array1[a][b]==array1[a+1][b])&&array1[a][b+1]==array1[a+3][b]))||(array1[a][b]==array1[a][b+2])&&((array1[a][b+2]==array1[a][b+3]))||(array1[a][b]==array1[a][b+1])
&&(((array1[a][b+1]==array1[a+1][b+1]))||(array1[a][b]==array1[a+1][b])&&((array1[a+1][b]==array1[a+1][b+1]))))&&(((a2-a>0&&a2-a<2)||(a-a2>0&&a-a2<2))||((b2-b>0&&b2-b<2)||(b-b2>0&&b-b2<2))))
{



	t=arr[a][b];
	arr[a][b]=arr[a2][b2];
	arr[a2][b2]=t;
	



}

//&&(((a2-a>0&&a2-a<2)||(a-a2>0&&a-a2<2))||((b2-b>0&&b2-b<2)||(b-b2>0&&b-b2<2))))



}
void Draw::username()
{
	if(this->getoption()==5)
	{
		 for (int i = 0; i < 840; i++)
            {
            DrawSquare( 0, i ,i,colors[ORANGE]);
			 DrawString( 350, 540,"User Name:", colors[WHITE]); 
            DrawString( 350, 500,A.getsusername(), colors[WHITE]);
            DrawString( 350, 440,"No of Moves played", colors[WHITE]); 
            DrawString( 350, 400,to_string(this->getnoofmovesplayed()), colors[WHITE]); 
            DrawString( 350, 340,"Highscore", colors[WHITE]);      
			DrawString( 350, 300,to_string(A.gethighscore()), colors[WHITE]);     
            }
	}
}


int Draw::getcount()
{
	return count;
}
void Draw::setcount(int h)
{
count=h;

}
void Draw::gethint()
{
		int h=0,k=0; bool ch=true;
	for(int i=120;i<800;)
	{
		k=0;
		for(int j=120;j<800;)
		{
			if(ch)
			{
				this->setnoofmoves(this->getnoofmoves()-1);
				ch=false;
			}


			if(array1[h][k]==array1[h][k+1]&&array1[h][k+1]==array1[h][k+3])
			{

				arr[h][k]=9;
				arr[h][k+1]=9;
				arr[h][k+3]=9;
				break;
				}
			else if(array1[h][k]==array1[h][k+2]&&array1[h][k+2]==array1[h][k+3])
			{

				arr[h][k]=9;
				arr[h][k+2]=9;
				arr[h][k+3]=9;
				break;
				}	

		
			else if(array1[h][k]==array1[h+2][k]&&array1[h+2][k]==array1[h+3][k])
					{

				arr[h][k]=9;
				arr[h+2][k]=9;
				arr[h+3][k]=9;
				break;
					}
			else if(array1[h][k]==array1[h+1][k]&&array1[h+1][k]==array1[h+3][k])
			{

				arr[h][k]=9;
				arr[h+1][k]=9;
				arr[h+1][k]=9;
				break;
				}	






			 k++;
					j=j+90.25;	
		}
		  h++;
			  i=i+90.25;
	}
		
}

void Draw::time1()
{
timee=glutGet(GLUT_ELAPSED_TIME)/1500;

timeee=Num2Str(timee);
DrawString( 10, 580,"Time", colors[MISTY_ROSE]);
DrawString( 10, 560,timeee, colors[MISTY_ROSE]);



}
