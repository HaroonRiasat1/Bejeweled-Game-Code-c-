#ifndef LEVEL_H
#define LEVEL_H
class classlevel
{
private:
    int lives=3;
    int noofmoves=15;
    int level=1;
    int noofmovesplayed=0;
public:
    classlevel(/* args */);
    int getlevel();
    void setlevel();
    int getlives();
    void setlives(int);
    int getnoofmoves();
    void setnoofmoves(int);
    int getnoofmovesplayed();
    void setnoofmovesplayed(int);





    ~classlevel(){};
};

#endif