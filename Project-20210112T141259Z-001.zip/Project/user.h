#ifndef USER_H
#define USER_H
#include<iostream>
#include<string>
using namespace std;
class User
{
    private:
    string username;
    int score;
    int highscore;

    public:
    User();
    User(string name);
    User(string name, int highscore);
    void sethighscore(int);
    int gethighscore();
    void setusername(string username);
    string getsusername();
    void setscore(int);
    int getscore();

friend istream &operator >> (istream &output,const User&);

};
#endif