#ifndef SOUND_H
#define SOUND_H
#include"irrKlang.h"
using namespace irrklang;
class soundmp3
{
private:
ISoundEngine *SoundEngine = createIrrKlangDevice();
ISoundEngine *SoundEngine2 = createIrrKlangDevice();
bool A=false;
public:

soundmp3();
void sound1();
void sound2();
void sound3();
void sound4();
void deletesound();







};
#endif