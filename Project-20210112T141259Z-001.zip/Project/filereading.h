#ifndef FILE_H
#define FILE_H
#include"user.h"
#include"fstream"
#include"classlevel.h"
class File:public User,public classlevel
{
private:
int data;
public:
File();
void fileread();
void highscorewrite(string user,int,int,int,int);





};
#endif 